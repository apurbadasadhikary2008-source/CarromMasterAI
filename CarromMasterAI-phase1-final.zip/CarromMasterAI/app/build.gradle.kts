plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

// LibGDX / Box2D ship their native .so files as classifier jars; they are unpacked into app/libs/<abi>.
val natives: Configuration by configurations.creating
val nativeAbis = listOf("armeabi-v7a", "arm64-v8a", "x86_64")

android {
    namespace = "com.carrommaster.ai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.carrommaster.ai"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
        ndk { abiFilters += nativeAbis }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }

    sourceSets { getByName("main") { jniLibs.srcDir("libs") } }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.fragment.ktx)
    implementation(libs.androidx.lifecycle.runtime)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.kotlinx.coroutines.android)

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.material3)
    implementation(libs.compose.ui.tooling.preview)
    debugImplementation(libs.compose.ui.tooling)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.gdx)
    implementation(libs.gdx.backend.android)
    implementation(libs.gdx.box2d)
    val gdxVersion = libs.versions.gdx.get()
    nativeAbis.forEach { abi ->
        natives("com.badlogicgames.gdx:gdx-platform:$gdxVersion:natives-$abi")
        natives("com.badlogicgames.gdx:gdx-box2d-platform:$gdxVersion:natives-$abi")
    }

    implementation(libs.opencv)

    testImplementation(libs.junit)
}

val copyAndroidNatives by tasks.registering {
    doFirst {
        natives.files.forEach { jar ->
            val abi = nativeAbis.first { jar.name.endsWith("natives-$it.jar") }
            val outDir = layout.projectDirectory.dir("libs/$abi").asFile
            outDir.mkdirs()
            copy {
                from(zipTree(jar))
                into(outDir)
                include("*.so")
            }
        }
    }
}

tasks.configureEach {
    if (name.contains("JniLibFolders")) dependsOn(copyAndroidNatives)
}
