package com.carrommaster.ai.core.model

enum class CoinColor { BLACK, WHITE, QUEEN, STRIKER }

data class Coin(
    val id: Int,
    val color: CoinColor,
    val position: Vec2,
    val radius: Float,
)

/** A snapshot of the board: used as the common input of every planner. */
data class BoardState(
    val coins: List<Coin>,
    val striker: Coin?,
)
