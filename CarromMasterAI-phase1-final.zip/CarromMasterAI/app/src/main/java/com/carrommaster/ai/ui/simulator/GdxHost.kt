package com.carrommaster.ai.ui.simulator

import android.content.Context
import android.content.ContextWrapper
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentContainerView
import com.carrommaster.ai.R
import com.carrommaster.ai.simulator.host.SimulatorFragment

private tailrec fun Context.findFragmentActivity(): FragmentActivity = when (this) {
    is FragmentActivity -> this
    is ContextWrapper -> baseContext.findFragmentActivity()
    else -> error("No FragmentActivity found")
}

/** Embeds the LibGDX fragment inside Compose. */
@Composable
fun GdxHost(fragment: SimulatorFragment, modifier: Modifier = Modifier) {
    val activity = LocalContext.current.findFragmentActivity()

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            FragmentContainerView(ctx).apply {
                id = R.id.gdx_container
                post {
                    val fm = activity.supportFragmentManager
                    if (fm.findFragmentById(R.id.gdx_container) == null) {
                        fm.beginTransaction().replace(R.id.gdx_container, fragment).commitAllowingStateLoss()
                    }
                }
            }
        },
    )

    DisposableEffect(fragment) {
        onDispose {
            val fm = activity.supportFragmentManager
            if (!fm.isStateSaved && fragment.isAdded) {
                fm.beginTransaction().remove(fragment).commitAllowingStateLoss()
            }
        }
    }
}
