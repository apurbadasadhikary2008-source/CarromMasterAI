package com.carrommaster.ai.simulator.host

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration
import com.badlogic.gdx.backends.android.AndroidFragmentApplication
import com.carrommaster.ai.simulator.engine.SimulatorGame

/** Hosts the LibGDX surface inside the Compose UI. The host activity must implement Callbacks. */
class SimulatorFragment : AndroidFragmentApplication() {
    val game = SimulatorGame()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        val config = AndroidApplicationConfiguration().apply {
            numSamples = 2
            useWakelock = false
        }
        return initializeForView(game, config)
    }
}
