package com.carrommaster.ai.analyzer.vision

import org.opencv.android.OpenCVLoader
import org.opencv.core.Core

/** Module A: one-time OpenCV native initialisation. */
object OpenCvRuntime {
    @Volatile
    var ready: Boolean = false
        private set

    fun init(): Boolean {
        ready = try {
            OpenCVLoader.initLocal()
        } catch (t: Throwable) {
            false
        }
        return ready
    }

    fun versionString(): String = if (ready) Core.VERSION else "not available"
}
