package com.carrommaster.ai.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.carrommaster.ai.ui.analyzer.AnalyzerScreen
import com.carrommaster.ai.ui.home.HomeScreen
import com.carrommaster.ai.ui.simulator.SimulatorScreen

object Routes {
    const val HOME = "home"
    const val ANALYZER = "analyzer"
    const val SIMULATOR = "simulator"
}

@Composable
fun CarromNavHost() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onOpenAnalyzer = { nav.navigate(Routes.ANALYZER) },
                onOpenSimulator = { nav.navigate(Routes.SIMULATOR) },
            )
        }
        composable(Routes.ANALYZER) { AnalyzerScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.SIMULATOR) { SimulatorScreen(onBack = { nav.popBackStack() }) }
    }
}
