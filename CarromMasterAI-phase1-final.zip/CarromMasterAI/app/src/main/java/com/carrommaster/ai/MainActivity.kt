package com.carrommaster.ai

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.fragment.app.FragmentActivity
import com.badlogic.gdx.backends.android.AndroidFragmentApplication
import com.carrommaster.ai.ui.nav.CarromNavHost
import com.carrommaster.ai.ui.theme.CarromTheme

class MainActivity : FragmentActivity(), AndroidFragmentApplication.Callbacks {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CarromTheme { CarromNavHost() } }
    }

    override fun exit() = Unit
}
