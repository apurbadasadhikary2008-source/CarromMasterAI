package com.carrommaster.ai.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "matches")
data class MatchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mode: String,
    val startedAtMs: Long,
    val finishedAtMs: Long? = null,
    val winner: String? = null,
    val blackScore: Int = 0,
    val whiteScore: Int = 0,
)
