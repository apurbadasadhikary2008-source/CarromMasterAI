package com.carrommaster.ai

import android.app.Application
import com.carrommaster.ai.analyzer.vision.OpenCvRuntime
import com.carrommaster.ai.data.AppDatabase

class CarromApp : Application() {
    val database: AppDatabase by lazy { AppDatabase.get(this) }

    override fun onCreate() {
        super.onCreate()
        OpenCvRuntime.init()
    }
}
