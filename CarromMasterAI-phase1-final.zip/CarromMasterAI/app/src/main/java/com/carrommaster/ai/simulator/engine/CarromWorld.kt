package com.carrommaster.ai.simulator.engine

import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.physics.box2d.Body
import com.badlogic.gdx.physics.box2d.BodyDef
import com.badlogic.gdx.physics.box2d.CircleShape
import com.badlogic.gdx.physics.box2d.FixtureDef
import com.badlogic.gdx.physics.box2d.PolygonShape
import com.badlogic.gdx.physics.box2d.World
import com.carrommaster.ai.core.model.BoardSpec
import com.carrommaster.ai.core.model.BoardState
import com.carrommaster.ai.core.model.Coin
import com.carrommaster.ai.core.model.CoinColor
import com.carrommaster.ai.core.model.ShotPlan
import com.carrommaster.ai.core.model.StartingLayout
import com.carrommaster.ai.core.model.Vec2
import kotlin.math.cos
import kotlin.math.sin

data class PocketEvent(val coin: Coin, val pocketIndex: Int)

/**
 * Module B: the Box2D carrom world. Top-down, so gravity is zero and friction is linear damping.
 * Call Box2D.init() once before constructing.
 */
class CarromWorld {
    private val world = World(Vector2(0f, 0f), true)
    private val discs = LinkedHashMap<Int, Body>()
    private var strikerBody: Body? = null

    init {
        buildWalls()
        resetMatch()
    }

    fun resetMatch() {
        discs.values.forEach { world.destroyBody(it) }
        discs.clear()
        strikerBody?.let { world.destroyBody(it) }
        strikerBody = null
        StartingLayout.standard().forEach { discs[it.id] = createDisc(it, COIN_DENSITY, false) }
        spawnStriker(0f)
    }

    fun placeStriker(x: Float) {
        strikerBody?.apply {
            setTransform(BoardSpec.clampBaselineX(x), BoardSpec.BASELINE_Y, 0f)
            setLinearVelocity(0f, 0f)
        }
    }

    /** Executes a shot with the simulator's own physics: an impulse on the striker. */
    fun shoot(plan: ShotPlan) {
        val body = strikerBody ?: return
        placeStriker(plan.strikerPosition.x)
        val speed = MAX_STRIKER_SPEED * plan.power.coerceIn(0f, 1f)
        val impulse = speed * body.mass
        body.applyLinearImpulse(
            cos(plan.angleRad) * impulse, sin(plan.angleRad) * impulse,
            body.worldCenter.x, body.worldCenter.y, true,
        )
    }

    /** Advances physics and returns coins/striker that fell into a pocket during this step. */
    fun step(dt: Float): List<PocketEvent> {
        world.step(dt, 8, 3)
        return collectPocketed()
    }

    fun isSettled(): Boolean {
        for (b in discs.values) if (b.linearVelocity.len2() > SETTLE_SPEED_SQ) return false
        val s = strikerBody
        return s == null || s.linearVelocity.len2() <= SETTLE_SPEED_SQ
    }

    fun snapshot(): BoardState =
        BoardState(discs.values.map { coinOf(it) }, strikerBody?.let { coinOf(it) })

    fun forEachDisc(block: (color: CoinColor, x: Float, y: Float, r: Float) -> Unit) {
        for (b in discs.values) {
            val c = b.userData as Coin
            block(c.color, b.position.x, b.position.y, c.radius)
        }
        strikerBody?.let { block(CoinColor.STRIKER, it.position.x, it.position.y, BoardSpec.STRIKER_RADIUS) }
    }

    fun dispose() = world.dispose()

    // ---- internals ----

    private fun spawnStriker(x: Float) {
        val c = Coin(
            STRIKER_ID, CoinColor.STRIKER,
            Vec2(BoardSpec.clampBaselineX(x), BoardSpec.BASELINE_Y), BoardSpec.STRIKER_RADIUS,
        )
        strikerBody = createDisc(c, STRIKER_DENSITY, true)
    }

    private fun createDisc(c: Coin, density: Float, fast: Boolean): Body {
        val def = BodyDef().apply {
            type = BodyDef.BodyType.DynamicBody
            position.set(c.position.x, c.position.y)
            linearDamping = LINEAR_DAMPING
            angularDamping = 3f
            bullet = fast
        }
        val body = world.createBody(def)
        val circle = CircleShape().apply { radius = c.radius }
        val fixture = FixtureDef().apply {
            this.shape = circle
            this.density = density
            friction = 0.1f
            restitution = 0.8f
        }
        body.createFixture(fixture)
        circle.dispose()
        body.userData = c
        return body
    }

    private fun buildWalls() {
        val t = WALL_HALF_THICKNESS
        val h = BoardSpec.HALF
        addWall(0f, h + t, h + t, t)
        addWall(0f, -(h + t), h + t, t)
        addWall(h + t, 0f, t, h + t)
        addWall(-(h + t), 0f, t, h + t)
    }

    private fun addWall(cx: Float, cy: Float, hx: Float, hy: Float) {
        val body = world.createBody(BodyDef())
        val box = PolygonShape().apply { setAsBox(hx, hy) }
        val fixture = FixtureDef().apply {
            this.shape = box
            friction = 0.1f
            restitution = 0.7f
        }
        body.createFixture(fixture)
        box.dispose()
        body.setTransform(cx, cy, 0f)
    }

    private fun coinOf(b: Body): Coin =
        (b.userData as Coin).copy(position = Vec2(b.position.x, b.position.y))

    private fun pocketAt(b: Body): Int {
        val r2 = BoardSpec.POCKET_RADIUS * BoardSpec.POCKET_RADIUS
        BoardSpec.POCKETS.forEachIndexed { i, p ->
            val dx = b.position.x - p.x
            val dy = b.position.y - p.y
            if (dx * dx + dy * dy < r2) return i
        }
        return -1
    }

    private fun collectPocketed(): List<PocketEvent> {
        var events: MutableList<PocketEvent>? = null
        val iter = discs.entries.iterator()
        while (iter.hasNext()) {
            val e = iter.next()
            val idx = pocketAt(e.value)
            if (idx >= 0) {
                if (events == null) events = ArrayList()
                events.add(PocketEvent(coinOf(e.value), idx))
                world.destroyBody(e.value)
                iter.remove()
            }
        }
        val s = strikerBody
        if (s != null) {
            val idx = pocketAt(s)
            if (idx >= 0) {
                if (events == null) events = ArrayList()
                events.add(PocketEvent(coinOf(s), idx))
                world.destroyBody(s)
                strikerBody = null
                spawnStriker(0f)
            }
        }
        return events ?: emptyList()
    }

    companion object {
        const val STRIKER_ID = -1
        const val COIN_DENSITY = 1f
        const val STRIKER_DENSITY = 1.8f
        const val LINEAR_DAMPING = 1.3f
        const val MAX_STRIKER_SPEED = 30f   // units/s (= 3 m/s)
        const val SETTLE_SPEED_SQ = 0.01f
        const val WALL_HALF_THICKNESS = 0.25f
    }
}
