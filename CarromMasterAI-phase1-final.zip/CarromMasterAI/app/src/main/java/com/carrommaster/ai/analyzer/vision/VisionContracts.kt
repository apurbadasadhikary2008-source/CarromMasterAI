package com.carrommaster.ai.analyzer.vision

import android.graphics.Bitmap
import com.carrommaster.ai.core.model.BoardState
import com.carrommaster.ai.core.model.Vec2

/** Board quad in image pixels: top-left, top-right, bottom-right, bottom-left. */
data class BoardDetection(val cornersPx: List<Vec2>)

/** Phase 2 implements this with OpenCV. */
interface BoardDetector {
    fun detect(screenshot: Bitmap): BoardDetection?
}

/** Phase 3 implements this: pixels -> BoardState in board units (core.model.BoardSpec). */
interface CoinRecognizer {
    fun recognize(screenshot: Bitmap, board: BoardDetection): BoardState
}
