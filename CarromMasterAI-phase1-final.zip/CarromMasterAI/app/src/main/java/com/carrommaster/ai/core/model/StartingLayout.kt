package com.carrommaster.ai.core.model

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Standard opening: queen centre, ring of 6, outer ring of 12 (9 black + 9 white + queen = 19). */
object StartingLayout {
    private const val GAP = 1.02f // tiny spacing so no pair starts overlapping

    fun standard(): List<Coin> {
        val r = BoardSpec.COIN_RADIUS
        val coins = ArrayList<Coin>(19)
        var id = 0
        coins += Coin(id++, CoinColor.QUEEN, Vec2.ZERO, r)

        for (k in 0 until 6) {
            val angle = 90f + k * 60f
            val color = if (k % 2 == 0) CoinColor.BLACK else CoinColor.WHITE
            coins += Coin(id++, color, polar(2f * r * GAP, angle), r)
        }
        for (k in 0 until 6) {
            val angle = 90f + k * 60f
            val color = if (k % 2 == 0) CoinColor.BLACK else CoinColor.WHITE
            coins += Coin(id++, color, polar(4f * r * GAP, angle), r)
            coins += Coin(id++, opposite(color), polar(2f * sqrt(3f) * r * GAP, angle + 30f), r)
        }
        return coins
    }

    private fun opposite(c: CoinColor) = if (c == CoinColor.BLACK) CoinColor.WHITE else CoinColor.BLACK

    private fun polar(dist: Float, deg: Float): Vec2 {
        val a = Math.toRadians(deg.toDouble())
        return Vec2((dist * cos(a)).toFloat(), (dist * sin(a)).toFloat())
    }
}
