package com.carrommaster.ai.core.model

/**
 * Canonical board geometry shared by BOTH modules.
 * Units: 1 unit = 10 cm (keeps Box2D well-scaled). Origin = board centre, +y = up.
 * Values approximate a standard 74 cm playing surface; tune in later phases.
 */
object BoardSpec {
    const val SIDE = 7.4f
    const val HALF = SIDE / 2f
    const val COIN_RADIUS = 0.159f
    const val STRIKER_RADIUS = 0.206f
    const val POCKET_INSET = 0.2f
    const val POCKET_RADIUS = 0.30f          // capture radius around pocket centre
    const val BASELINE_Y = -2.7f
    const val BASELINE_HALF_LENGTH = 2.0f

    val POCKETS: List<Vec2> = run {
        val c = HALF - POCKET_INSET
        listOf(Vec2(-c, -c), Vec2(c, -c), Vec2(c, c), Vec2(-c, c))
    }

    fun clampBaselineX(x: Float): Float = x.coerceIn(-BASELINE_HALF_LENGTH, BASELINE_HALF_LENGTH)
}
