package com.carrommaster.ai.core.model

import kotlin.math.sqrt

/** Immutable 2D vector. Board units: 1 unit = 10 cm, origin = board centre, +y = up. */
data class Vec2(val x: Float, val y: Float) {
    operator fun plus(o: Vec2) = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = Vec2(x - o.x, y - o.y)
    operator fun times(s: Float) = Vec2(x * s, y * s)
    fun length(): Float = sqrt(x * x + y * y)
    fun distanceTo(o: Vec2): Float = (this - o).length()

    companion object {
        val ZERO = Vec2(0f, 0f)
    }
}
