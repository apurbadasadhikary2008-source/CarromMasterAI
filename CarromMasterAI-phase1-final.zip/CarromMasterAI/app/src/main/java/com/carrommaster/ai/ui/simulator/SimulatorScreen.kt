package com.carrommaster.ai.ui.simulator

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.carrommaster.ai.simulator.host.SimulatorFragment

@Composable
fun SimulatorScreen(onBack: () -> Unit) {
    val fragment = remember { SimulatorFragment() }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            Text("Module B · Autonomous Simulator", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            GdxHost(fragment = fragment, modifier = Modifier.fillMaxWidth().weight(1f))
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { fragment.game.fireTestShot() }, modifier = Modifier.weight(1f)) { Text("Test shot") }
                Spacer(Modifier.width(8.dp))
                Button(onClick = { fragment.game.resetMatch() }, modifier = Modifier.weight(1f)) { Text("Reset") }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back") }
        }
    }
}
