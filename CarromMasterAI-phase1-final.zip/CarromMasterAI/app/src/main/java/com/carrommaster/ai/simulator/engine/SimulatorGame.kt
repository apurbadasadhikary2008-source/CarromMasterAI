package com.carrommaster.ai.simulator.engine

import com.badlogic.gdx.ApplicationListener
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.physics.box2d.Box2D
import com.badlogic.gdx.utils.viewport.FitViewport
import com.carrommaster.ai.core.model.BoardSpec
import com.carrommaster.ai.core.model.CoinColor
import com.carrommaster.ai.core.model.ShotPlan
import com.carrommaster.ai.core.model.Vec2
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.min

/**
 * Module B: LibGDX render loop + fixed-step physics.
 * Commands from the UI thread are queued and run on the GL thread (Box2D is not thread-safe).
 */
class SimulatorGame : ApplicationListener {

    private lateinit var camera: OrthographicCamera
    private lateinit var viewport: FitViewport
    private lateinit var shapes: ShapeRenderer
    private lateinit var carrom: CarromWorld

    private val commands = ConcurrentLinkedQueue<() -> Unit>()
    private var accumulator = 0f

    fun resetMatch() { commands.add { carrom.resetMatch() } }

    /** Straight test shot from the baseline to verify physics visually. */
    fun fireTestShot() {
        commands.add {
            carrom.shoot(ShotPlan(Vec2(0f, BoardSpec.BASELINE_Y), (Math.PI / 2).toFloat(), 0.6f))
        }
    }

    override fun create() {
        Box2D.init()
        camera = OrthographicCamera()
        viewport = FitViewport(VIEW, VIEW, camera)
        shapes = ShapeRenderer()
        carrom = CarromWorld()
    }

    override fun resize(width: Int, height: Int) {
        viewport.update(width, height, false)
        camera.position.set(0f, 0f, 0f)
        camera.update()
    }

    override fun render() {
        while (true) {
            val job = commands.poll() ?: break
            job()
        }
        accumulator += min(Gdx.graphics.deltaTime, 0.1f)
        while (accumulator >= STEP) {
            carrom.step(STEP)
            accumulator -= STEP
        }

        Gdx.gl.glClearColor(0.07f, 0.08f, 0.1f, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT)
        viewport.apply()
        camera.update()
        shapes.projectionMatrix = camera.combined
        draw()
    }

    private fun draw() {
        val h = BoardSpec.HALF
        shapes.begin(ShapeRenderer.ShapeType.Filled)
        shapes.setColor(0.35f, 0.2f, 0.08f, 1f)
        shapes.rect(-h - 0.5f, -h - 0.5f, BoardSpec.SIDE + 1f, BoardSpec.SIDE + 1f)
        shapes.setColor(0.93f, 0.8f, 0.58f, 1f)
        shapes.rect(-h, -h, BoardSpec.SIDE, BoardSpec.SIDE)
        shapes.setColor(0.05f, 0.05f, 0.05f, 1f)
        for (p in BoardSpec.POCKETS) shapes.circle(p.x, p.y, BoardSpec.POCKET_RADIUS, 24)
        carrom.forEachDisc { color, x, y, r ->
            when (color) {
                CoinColor.BLACK -> shapes.setColor(0.08f, 0.08f, 0.08f, 1f)
                CoinColor.WHITE -> shapes.setColor(0.96f, 0.96f, 0.94f, 1f)
                CoinColor.QUEEN -> shapes.setColor(0.8f, 0.12f, 0.2f, 1f)
                CoinColor.STRIKER -> shapes.setColor(0.2f, 0.5f, 0.95f, 1f)
            }
            shapes.circle(x, y, r, 24)
        }
        shapes.end()

        shapes.begin(ShapeRenderer.ShapeType.Line)
        shapes.setColor(0.3f, 0.2f, 0.1f, 1f)
        val bl = BoardSpec.BASELINE_HALF_LENGTH
        shapes.line(-bl, BoardSpec.BASELINE_Y, bl, BoardSpec.BASELINE_Y)
        shapes.end()
    }

    override fun pause() = Unit
    override fun resume() = Unit

    override fun dispose() {
        shapes.dispose()
        carrom.dispose()
    }

    companion object {
        private const val VIEW = 8.6f
        private const val STEP = 1f / 120f
    }
}
