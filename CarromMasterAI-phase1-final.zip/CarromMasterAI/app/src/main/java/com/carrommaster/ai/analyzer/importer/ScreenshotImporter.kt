package com.carrommaster.ai.analyzer.importer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max

/** Module A: loads a user-picked screenshot from disk. Read-only; never touches another app. */
class ScreenshotImporter(private val context: Context) {

    suspend fun load(uri: Uri, maxEdge: Int = 2048): Result<Bitmap> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Unreadable image" }

            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxEdge) sample *= 2

            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val bitmap = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            checkNotNull(bitmap) { "Decode failed" }
        }
    }
}
