package com.carrommaster.ai.core.ai

import com.carrommaster.ai.core.model.BoardState
import com.carrommaster.ai.core.model.CoinColor
import com.carrommaster.ai.core.model.ShotCandidate

/**
 * Pure-Kotlin contract implemented in a later phase and consumed by both modules.
 * It depends only on core.model, so Module A and Module B never depend on each other.
 */
interface ShotPlanner {
    /** Returns candidates sorted best-first. */
    fun plan(state: BoardState, side: CoinColor): List<ShotCandidate>
}
