package com.carrommaster.ai.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MatchDao {
    @Insert
    suspend fun insert(match: MatchEntity): Long

    @Update
    suspend fun update(match: MatchEntity)

    @Query("SELECT * FROM matches ORDER BY startedAtMs DESC")
    fun observeAll(): Flow<List<MatchEntity>>
}
