package com.carrommaster.ai.core.model

enum class GameMode { HUMAN_VS_AI, AI_VS_AI }

/**
 * A fully specified shot. angleRad: 0 = +x, counter-clockwise. power: 0..1.
 * Used by Module A to *display* a recommendation and by Module B to *execute* in its own simulator.
 */
data class ShotPlan(
    val strikerPosition: Vec2,
    val angleRad: Float,
    val power: Float,
)

data class ShotCandidate(
    val plan: ShotPlan,
    val score: Float,
    val label: String,
)
