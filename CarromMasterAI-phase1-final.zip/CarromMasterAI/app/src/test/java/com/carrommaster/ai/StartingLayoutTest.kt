package com.carrommaster.ai

import com.carrommaster.ai.core.model.BoardSpec
import com.carrommaster.ai.core.model.CoinColor
import com.carrommaster.ai.core.model.StartingLayout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class StartingLayoutTest {
    private val coins = StartingLayout.standard()

    @Test
    fun hasNineteenCoinsWithCorrectColours() {
        assertEquals(19, coins.size)
        assertEquals(9, coins.count { it.color == CoinColor.BLACK })
        assertEquals(9, coins.count { it.color == CoinColor.WHITE })
        assertEquals(1, coins.count { it.color == CoinColor.QUEEN })
    }

    @Test
    fun noTwoCoinsOverlap() {
        for (i in coins.indices) for (j in i + 1 until coins.size) {
            val d = coins[i].position.distanceTo(coins[j].position)
            assertTrue("coins ${coins[i].id}/${coins[j].id} overlap (d=$d)", d >= 2f * BoardSpec.COIN_RADIUS)
        }
    }

    @Test
    fun allCoinsInsideBoardAndQueenCentred() {
        coins.forEach {
            assertTrue(abs(it.position.x) < BoardSpec.HALF && abs(it.position.y) < BoardSpec.HALF)
        }
        assertEquals(0f, coins.first { it.color == CoinColor.QUEEN }.position.length(), 1e-6f)
    }
}
