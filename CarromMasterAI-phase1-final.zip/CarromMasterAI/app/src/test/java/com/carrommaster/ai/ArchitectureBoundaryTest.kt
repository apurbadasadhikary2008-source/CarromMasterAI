package com.carrommaster.ai

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Enforces: Module A and Module B stay separate, and nothing automates other apps. */
class ArchitectureBoundaryTest {
    private val root = File("src/main/java/com/carrommaster/ai")

    private fun sources(sub: String): List<File> {
        val dir = File(root, sub)
        assertTrue("missing source dir $dir", dir.isDirectory)
        return dir.walkTopDown().filter { it.extension == "kt" }.toList()
    }

    @Test
    fun analyzerDoesNotDependOnSimulator() {
        sources("analyzer").forEach {
            assertFalse("${it.name} imports simulator", it.readText().contains("com.carrommaster.ai.simulator"))
        }
    }

    @Test
    fun simulatorDoesNotDependOnAnalyzer() {
        sources("simulator").forEach {
            assertFalse("${it.name} imports analyzer", it.readText().contains("com.carrommaster.ai.analyzer"))
        }
    }

    @Test
    fun coreDependsOnNeitherModule() {
        sources("core").forEach {
            val t = it.readText()
            assertFalse(t.contains("com.carrommaster.ai.analyzer"))
            assertFalse(t.contains("com.carrommaster.ai.simulator"))
        }
    }

    @Test
    fun noInputAutomationAgainstOtherApps() {
        val banned = listOf(
            "AccessibilityService", "dispatchGesture", "injectInputEvent",
            "MediaProjection", "SYSTEM_ALERT_WINDOW", "UiAutomation",
        )
        val files = root.walkTopDown().filter { it.extension == "kt" }.toList() +
            File("src/main/AndroidManifest.xml")
        files.forEach { f ->
            val t = f.readText()
            banned.forEach { assertFalse("${f.name} contains $it", t.contains(it)) }
        }
    }
}
